// Version Mac native (sans Capacitor) : une fenêtre qui affiche public/index.html
// À mettre dans une cible macOS (File > New > Target > macOS > App, interface SwiftUI)
// en remplacement du fichier <NomDeLaCible>App.swift généré par Xcode.

import SwiftUI
import WebKit

@main
struct MacGameApp: App {
    var body: some Scene {
        WindowGroup {
            GameWebView()
                .frame(minWidth: 900, minHeight: 560)
                .background(Color(red: 7/255, green: 5/255, blue: 16/255)) // #070510
                .ignoresSafeArea()
        }
        .defaultSize(width: 1280, height: 800)
        .commands { CommandGroup(replacing: .newItem) {} } // pas de « Nouvelle fenêtre »
    }
}

struct GameWebView: NSViewRepresentable {
    func makeNSView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()                    // garde scores et réglages (localStorage)
        config.mediaTypesRequiringUserActionForPlayback = []   // son sans clic préalable

        let web = WKWebView(frame: .zero, configuration: config)
        web.setValue(false, forKey: "drawsBackground")          // pas de flash blanc au lancement

        // Xcode peut copier "public" comme sous-dossier OU à plat dans Resources : on essaie les deux.
        let page = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "public")
                ?? Bundle.main.url(forResource: "index", withExtension: "html")
        if let page {
            web.loadFileURL(page, allowingReadAccessTo: page.deletingLastPathComponent())
        } else {
            print("⚠️ index.html introuvable dans le bundle")
            web.loadHTMLString("<body style='background:#070510;color:#fff;font:20px -apple-system;padding:40px'>index.html introuvable dans l'app</body>", baseURL: nil)
        }

        // Donne le clavier au jeu dès l'ouverture (flèches, Q/D, Espace)
        DispatchQueue.main.async { web.window?.makeFirstResponder(web) }
        return web
    }

    func updateNSView(_ nsView: WKWebView, context: Context) {}
}

